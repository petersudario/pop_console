//
//  main.swift
//  pop_console
//
//  Created by Pedro Henrique Sudario da Silva on 25/03/25.
//


protocol Notifiable {
    var message: Message { get set }
    func sendNotification() -> Void
}

struct Email: Notifiable {
    var emailAddress: String
    var message: Message
    func sendNotification() -> Void {
        print(message)
    }
}

struct Sms: Notifiable {
    var phoneNumber: String
    var message: Message
    func sendNotification() -> Void {
        print(message)
    }
}

struct PushNotification: Notifiable {
    var deviceToken: String
    var message: Message
    func sendNotification() -> Void {
        print(message)
    }
}

extension Notifiable {
    func sendNotification() -> Void {
        print("Enviando notificação...")
    }
}

enum MessageType {
    case promo
    case reminder
    case alert
}

struct Message {
    var type: MessageType
    var content: String
}

var items: [Notifiable] = [
    
]

for item in items {
    item.sendNotification()
}

